#include "iostream"
using namespace std;
int main()
{
	// TODO:read standard input
	// TODO:process
	// TODO:write standard output
	// TODO:fflush(stdout);
	std::cout << "test bulid" << std::endl;
	return 0;
}
